**Material for [ZhiHu post](https://zhuanlan.zhihu.com/p/25354571) that describes basic lane detection.**

lane_detection_1.py is for video_1.mp4 and video_2.mp4
lane_detection_2.py is for video_3.mp4

lane_detection_2.py's method is a superset of and more powerful than lane_detection_1.py's method, but needs
some parameter tuning when applying to video_1.mp4 and video_2.mp4.


**Usage**

Change the input video path and output video path in the last several lines of the python file, then
```
python PYTHON_FILE_NAME
```
